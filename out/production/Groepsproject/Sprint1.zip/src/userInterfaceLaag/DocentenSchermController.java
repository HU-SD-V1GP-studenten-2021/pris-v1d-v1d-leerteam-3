package userInterfaceLaag;

import domeinLaag.Docent;
import domeinLaag.Les;
import domeinLaag.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.ArrayList;

public class DocentenSchermController {
    @FXML private Rectangle rectangleBoven;
    @FXML private Button loguitKnop;
    @FXML public Label naamLabel;
    @FXML private TableView tableView2;
    @FXML private TableColumn<Les, String> klasid;
    @FXML private TableColumn<Les, String> datumid;
    @FXML private TableColumn<Les, String> lesid;

    @FXML private TableView tableView1;
    @FXML private TableColumn<Student, String> naamid;
    @FXML private TableColumn<Student, String> studentid;
    @FXML private TableColumn<Student, String> emailid;
    @FXML private TableColumn<Student, String> rollcall;


    private Docent docent = Docent.getAccount();

    public void initialize() throws Exception {
        String s = docent.getNaam();
        naamLabel.setText(s);

        klasid.setCellValueFactory(new PropertyValueFactory<>("klas"));
        datumid.setCellValueFactory(new PropertyValueFactory<>("datum"));
        lesid.setCellValueFactory(new PropertyValueFactory<>("lesnummer"));

        naamid.setCellValueFactory(new PropertyValueFactory<>("naam"));
        studentid.setCellValueFactory(new PropertyValueFactory<>("studentennummer"));
        emailid.setCellValueFactory(new  PropertyValueFactory<>("email"));
        rollcall.setCellValueFactory(new PropertyValueFactory<>("rollCall"));


        tableView2.setItems(getLessen());
        tableView1.setItems(getStudenten());
    }

    public ObservableList<Les> getLessen(){
        ObservableList<Les> lessen = FXCollections.observableArrayList();
        lessen.addAll(docent.getLessen());
        return lessen;
    }


    public ObservableList<Student> getStudenten(){
        ObservableList<Student> students = FXCollections.observableArrayList();

        Les les = docent.getLessen().get(0);

        students.addAll(les.getKlas().getStudenten());
        return students;
    }




    public void loguitEnAfsluiten(ActionEvent actionEvent){
        try {
            ((Node)actionEvent.getSource()).getScene().getWindow().hide();
            Stage primaryStage = new Stage();
            FXMLLoader loader = new FXMLLoader();
            Pane root = loader.load(getClass().getResource("/userInterfaceLaag/LoginScherm.fxml"));

            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.show();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void loadDataPerLes(MouseEvent mouseEvent) {
        Les les = (Les) tableView2.getSelectionModel().getSelectedItem();
        int lesnummer = les.getLesnummer();
        System.out.println(lesnummer);
        tableView1.setItems(getStudentenLoad(lesnummer));
    }
    public ObservableList<Student> getStudentenLoad(int lesnummer){
        ObservableList<Student> students = FXCollections.observableArrayList();
        ArrayList<Les> lessen = docent.getLessen();
        for (Les lesUitDeLijst : lessen){
            if (lesUitDeLijst.getLesnummer() == lesnummer){
                students.addAll(lesUitDeLijst.getKlas().getStudenten());
            }
        }
        return students;
    }

}

