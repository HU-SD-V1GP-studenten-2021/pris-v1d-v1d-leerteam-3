package userInterfaceLaag;

import java.util.Date;

public class ModelTable {
    int Les;

    public ModelTable(int les, String datum, String docent) {
        Les = les;
        Datum = datum;
        Docent = docent;

    }

    String Datum, Docent, Aanwezigheid;

}
